/**
 * Contains test classes used to verify the functionality of the
 * Inventory Management System. These tests are separate from the main
 * application and are a part of a different package
 */
package test;