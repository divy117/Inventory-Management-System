/**
 * -------------------------------------------------------------------------
 * File Name: InventorySystemTest.java
 * Project: Inventory Management System
 *
 * Description: Test cases for the InventorySystem class. Verifies core
 *              functionality such as loading, saving, adding, removing, updating,
 *              searching, and sorting items. Each test outputs pass/fail results
 *              to the console for quick inspection.
 *
 * -------------------------------------------------------------------------
 */


package test.testers;

import ims.logic.InventorySystem;
import ims.model.*;

import java.io.File;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;

public class InventorySystemTest {
    private InventorySystem sys = new InventorySystem();
    private static int testCount = 1;

    public void testClass(){
        System.out.println("================== InventorySystem Tests ==================");

        testLoad();
        testAdd();
        testRemove();
        testUpdate();
        testSearchByName();
        testSearchByID();
        testSearchByCategory();
        testSearchByPrice();
        testSort();
        testSave();
    }

    private void testAdd(){
        System.out.println("\n=========[TEST] addItem=========");

        try {
        // Base Case
        sys.addItem(new Perishable(
                sys.generateID(),
                "Cheese",
                10,
                2.00,
                5,
                LocalDate.of(2025, 12, 31)
        ));
        testResults("Item count after addition of 'Cheese' (4 item)", 4, sys.getAllItems().size());
        testResults("Item name matches 'Cheese'", "Cheese", sys.getAllItems().getLast().getName());

        // Base Case 2
            sys.addItem(new Clothing(
                    sys.generateID(),
                    "Red Shirt",
                    50,
                    5.00,
                    10,
                    "M")
            );
            testResults("Item count after addition of 'Red Shirt' (5 Items)", 5, sys.getAllItems().size());
            testResults("Red Shirt category matches Clothing category", Category.CLOTHING, sys.getAllItems().getLast().getCategory());

        // Edge Case, test if duplicate id is allowed
        boolean exceptionThrown = false;
        try {
            sys.addItem(new Electronic(
                    1000,
                    "iPhone",
                    15,
                    400,
                    10,
                    2)
            );
        } catch (Exception e){
            exceptionThrown = true;
        }
        testResults("Duplicate ID throws error", true, exceptionThrown);

        } catch (Exception e){
            System.out.println("[FAIL] addItem() threw exception: " + e.getMessage());
        }

    }

    private void testRemove(){
        System.out.println("\n=========[TEST] removeItem=========");
        try {
            // Base Case
            sys.removeItem(sys.getAllItems().getLast().getID());
            testResults("Item count - 1 after removal (4 Items)", 4, sys.getAllItems().size());

            // Verificaiton of base case
            boolean notRed = !sys.getAllItems().getLast().getName().equals("Red Shirt");
            testResults("Last item name is NOT 'Red Shirt'", true, notRed);


            // Edge Case: Test negative ID
            boolean exceptionThrown = false;
            try {
                int id = -1;
                sys.removeItem(id);
            } catch (Exception e){
                exceptionThrown = true;
            }
            testResults("Throws exception on negative id", true, exceptionThrown);

            // Edge Case: Test false ID doesn't exist
            exceptionThrown = false;
            try {
                int id = 1;
                sys.removeItem(id);
            } catch (Exception e){
                exceptionThrown = true;
            }
            testResults("Throws exception on non-existing item removal", true, exceptionThrown);


        } catch (Exception e) {
            System.out.println("[FAIL] removeItem() threw exception: " + e.getMessage());
        }
    }

    private void testUpdate(){
        System.out.println("\n=========[TEST] updateItem=========");

        // Base Case
        Perishable updatedItem = new Perishable(
                1000,
                "Milk Updated",
                10,
                2.5,
                3,
                LocalDate.of(2025,12,1)
        );
        sys.updateItem(1000, updatedItem);
        testResults("Updated Name of Milk -> Milk Updated", "Milk Updated", sys.getItem(1000).getName());


        // Edge Case: Test negative id
        boolean exceptionThrown = false;
        try {
            sys.updateItem(-1000, new Electronic(1, "TEST", 10, 10, 10, 10));
        } catch (Exception e) {
            exceptionThrown = true;
        }
        testResults("Throws exception when updating a negative id item", true, exceptionThrown);

        // Edge Case: Test non-existing item
        exceptionThrown = false;
        try {
            sys.updateItem(100000, new Electronic(1, "TEST", 10, 10, 10, 10));
        } catch (Exception e) {
            exceptionThrown = true;
        }
        testResults("Throws exception when updating non-existent item", true, exceptionThrown);

    }

    private void testSearchByName(){
        System.out.println("\n=========[TEST] searchByName=========");

        // Base Case
        ArrayList<Item> i1 = sys.searchByName("Milk Updated");
        testResults("Returned item name matches searched name 'Milk Updated'", "Milk Updated", i1.getFirst().getName());

        ArrayList<Item> i2 = sys.searchByName("");
        testResults("Returns empty list for empty search field", 0, i2.size());

        ArrayList<Item> i3 = sys.searchByName("MILK UPDATED");
        testResults("Tests for no case sensitivity", "Milk Updated", i3.getFirst().getName());

    }

    private void testSearchByID(){
        System.out.println("\n=========[TEST] searchByID=========");

        // Base Case
        ArrayList<Item> i1 = sys.searchByID(1000);
        testResults("Returns correct item for ID 1000", 1000, i1.getFirst().getID());

        // Invalid ID Range Search
        try {
            sys.searchByID(-20);
            testResults("Throws exception for negative ID", true, false); // Should not reach
        } catch (Exception e){
            testResults("Throws exception for negative ID", true, true);
        }

        // Non-existent ID returns empty list
        ArrayList<Item> i2 = sys.searchByID(99999);
        testResults("Returns empty list for non-existing ID", 0, i2.size());
    }

    private void testSearchByCategory(){
        System.out.println("\n=========[TEST] searchByCategory=========");

        // Base Case
        ArrayList<Item> i1 = sys.searchByCategory("PERISHABLE");
        testResults("Returned list should not be empty for PERISHABLE", true, !i1.isEmpty());
        testResults("First item category matches PERISHABLE", Category.PERISHABLE, i1.getFirst().getCategory());

        // Lowercase / mixed case check
        ArrayList<Item> i2 = sys.searchByCategory("clothing");
        testResults("Case-insensitive search is supported", Category.CLOTHING, i2.getFirst().getCategory());

        // Invalid category
        try {
            sys.searchByCategory("FOOD");
            testResults("Throws exception for invalid category", true, false);
        } catch (Exception e){
            testResults("Throws exception for invalid category", true, true);
        }
    }

    private void testSearchByPrice(){
        System.out.println("\n=========[TEST] searchByPrice=========");

        // Base Case
        ArrayList<Item> i1 = sys.searchByPrice(2);
        testResults("Returns item priced exactly at search price $2.00", 1, i1.size());
        testResults("Correct item returned", "Cheese", i1.getFirst().getName());

        // Items <= $20
        ArrayList<Item> i2_list = sys.searchByPrice(2.50);
        testResults("Returns all items <= 2.50", 2, i2_list.size());

        // No matches
        ArrayList<Item> i3 = sys.searchByPrice(0.99);
        testResults("Returns empty list if no item price <= threshold", 0, i3.size());
    }


    private void testSort(){
        System.out.println("\n=========[TEST] sorting functions=========");

        System.out.println("\n=========[TEST] sortByID()");
        System.out.println("Items BEFORE sortByID()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }

        sys.sortByID();

        System.out.println("\nItems AFTER sortByID()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }
        System.out.println();
        testResults("Position of Item 1", 1000, sys.getAllItems().get(0).getID());
        testResults("Position of Item 2", 1001, sys.getAllItems().get(1).getID());
        testResults("Position of Item 3", 1002, sys.getAllItems().get(2).getID());
        testResults("Position of Item 4", 1003, sys.getAllItems().get(3).getID());





        System.out.println("\n=========[TEST] sortByName()");
        System.out.println("Items BEFORE sortByName()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }

        sys.sortByName();

        System.out.println("\nItems AFTER sortByName()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }
        System.out.println();
        testResults("Position of Item 1", "Cheese", sys.getAllItems().get(0).getName());
        testResults("Position of Item 2", "Laptop", sys.getAllItems().get(1).getName());
        testResults("Position of Item 3", "Milk Updated", sys.getAllItems().get(2).getName());
        testResults("Position of Item 4", "Shirt", sys.getAllItems().get(3).getName());





        System.out.println("\n=========[TEST] sortByPrice()");
        System.out.println("Items BEFORE sortByPrice()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }

        sys.sortByPrice();

        System.out.println("\nItems AFTER sortByPrice()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }
        System.out.println();

        testResults("Position of Item 1", 2.00, sys.getAllItems().get(0).getUnitPrice());
        testResults("Position of Item 2", 2.5, sys.getAllItems().get(1).getUnitPrice());
        testResults("Position of Item 3", 19.99, sys.getAllItems().get(2).getUnitPrice());
        testResults("Position of Item 4", 999.99, sys.getAllItems().get(3).getUnitPrice());





        System.out.println("\n=========[TEST] sortByCategory()");
        System.out.println("Items BEFORE sortByCategory()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }

        sys.sortByCategory();

        System.out.println("\nItems AFTER sortByCategory()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }
        System.out.println();

        testResults("Position of Item 1", Category.PERISHABLE, sys.getAllItems().get(0).getCategory());
        testResults("Position of Item 2", Category.PERISHABLE, sys.getAllItems().get(1).getCategory());
        testResults("Position of Item 3", Category.ELECTRONIC, sys.getAllItems().get(2).getCategory());
        testResults("Position of Item 4", Category.CLOTHING, sys.getAllItems().get(3).getCategory());





        System.out.println("\n=========[TEST] sortByQuantity()");
        System.out.println("Items BEFORE sortByQuantity()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }

        sys.sortByQuantity();

        System.out.println("\nItems AFTER sortByQuantity()");
        printHeader();
        for (Item i: sys.getAllItems()){
            System.out.println(i);
        }
        System.out.println();

        testResults("Position of Item 1", 3, sys.getAllItems().get(0).getQuantity());
        testResults("Position of Item 2", 5, sys.getAllItems().get(1).getQuantity());
        testResults("Position of Item 3", 10, sys.getAllItems().get(2).getQuantity());
        testResults("Position of Item 4", 10, sys.getAllItems().get(3).getQuantity());
    }

    private void testLoad(){
        System.out.println("\n=========[TEST] load=========");

        try{
            File tempFile = File.createTempFile("tester_file", ".csv");

            PrintWriter writer = new PrintWriter(tempFile);
            writer.println("name,category,quantity,unitPrice,restockTrigger,expiry,warranty,size");
            writer.println("Milk,Perishable,10,2.5,3,2025-12-01,-,-");
            writer.println("Shirt,Clothing,5,19.99,2,-,-,M");
            writer.println("Laptop,Electronic,3,999.99,1,-,24,-");
            writer.close();

            sys.loadFromFile(tempFile.getAbsolutePath());

            testResults("Correct # of items loaded", 3, sys.getAllItems().size());

            Item first = sys.getAllItems().getFirst();
            testResults("Object Names are Matching", "Milk", first.getName());
            testResults("Categories Match", Category.PERISHABLE, first.getCategory());

            Item last = sys.getAllItems().getLast();
            testResults("Warranty Months Match", 24, ((Electronic) last).getWarrantyMonths());

        } catch (Exception e) {
            System.out.println("[FAIL] loadFromFile threw exception: " + e.getMessage());
        }

    }

    private void testSave(){
        System.out.println("\n=========[TEST] save=========");

        try {
            InventorySystem sys_error = new InventorySystem();

            boolean exceptionThrown = false;
            try {
                sys_error.saveToFile();
            } catch (Exception e){
                exceptionThrown = true;
            }
            testResults("Throws an exception for no file path", true, exceptionThrown);


            // Base Case

            // Write the expected output to the temp file first.
            File tempFile = File.createTempFile("save_test", "csv");
            PrintWriter writer = new PrintWriter(tempFile);
            writer.println("name,category,quantity,unitPrice,restockTrigger,expiry,warranty,size");
            writer.println("Laptop,Electronic,3,999.99,1,-,24,-");
            writer.println("Shirt,Clothing,5,19.99,2,-,-,M");
            writer.println("Cheese,Perishable,10,2.00,5,2025-12-31,-,-");
            writer.println("Milk Updated,Perishable,10,2.50,3,2025-12-01,-,-");
            writer.close();

            // Load the expected output into a new dummy system
            InventorySystem expected_output = new InventorySystem();
            expected_output.loadFromFile(tempFile.getAbsolutePath());

            // Save the current systems contents to the same file
            sys.setCurrentFilePath(tempFile.getAbsolutePath());
            sys.saveToFile();

            // Reload the new CSV file into another dummy system to see the actual saved content
            InventorySystem results = new InventorySystem();
            results.loadFromFile(tempFile.getAbsolutePath());

            // Compare names at each position, they should match.
            for (int i = 0; i < results.getAllItems().size(); i++) {
                testResults("Item name matches at index " + i,
                        expected_output.getAllItems().get(i).getName(),
                        results.getAllItems().get(i).getName());
            }


        } catch (Exception e) {
            System.out.println("[FAIL] saveToFile threw exception: " + e.getMessage());
        }

    }

    private void printHeader(){
        System.out.printf(
                "%-5s %-15s %-12s %-5s %-8s %-5s %-12s%n",
                "ID",
                "NAME",
                "CATEGORY",
                "QTY",
                "PRICE",
                "REST",
                "EXTRA"
        );
    };

    public void testResults(String testName, Object expected, Object actual) {
        if ((expected == null && actual == null) || (expected != null && expected.equals(actual))) {
            System.out.println("TEST " + testCount++ + " - [PASSED] " + testName);
        } else {
            System.out.println("TEST " + testCount++ + " - [FAILED] " + testName + ". Expected: " + expected + " but got: " + actual);
        }
    }

}
