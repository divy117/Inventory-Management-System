/**
 * -------------------------------------------------------------------------
 * File Name: Tester.java
 * Project: Inventory Management System
 *
 * Description: Entry point for running test cases Executes test classes
 *              to validate system functionality and behavior.
 *
 * -------------------------------------------------------------------------
 */


package test;

import test.testers.InventorySystemTest;

public class Tester {
    public static void main(String[] args) {
        InventorySystemTest inventorySystem = new InventorySystemTest();
        inventorySystem.testClass();
    }
}
