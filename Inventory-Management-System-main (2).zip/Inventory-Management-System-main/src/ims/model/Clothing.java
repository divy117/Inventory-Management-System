/**
 * -------------------------------------------------------------------------
 * File Name: Clothing.java
 * Project: Inventory Management System
 * Description: Represents a clothing item in the inventory. Extends the BasicItem class
 *              and adds specific attributes such as size, color, and fabric type.
 * -------------------------------------------------------------------------
 */

package ims.model;

/**
 * A clothing item that stores size, colour, and fabric details in addition
 * to the shared fields from {@link BasicItem}.
 */
public class Clothing extends BasicItem {
    /** Size label (e.g., S, M, L, XL). */
    private String size;

    /**
     * Constructs a new {@code Clothing}.
     *
     * @param id unique identifier
     * @param name item name
     * @param quantity non-negative quantity
     * @param unitPrice non-negative unit price
     * @param restockTrigger non-negative restock threshold
     * @param size size label (e.g., S, M, L, XL)
     */
    public Clothing(int id, String name, int quantity, double unitPrice, int restockTrigger, String size) {
        super(id, name, Category.CLOTHING, quantity, unitPrice, restockTrigger);
        this.size = size;
    };


    /**
     * Returns the size.
     *
     * @return size string
     */
    public String getSize(){return this.size;};


    /**
     * Updates the size.
     *
     * @param size new size string
     */
    public void setSize(String size){
        this.size = size;
    };

    /**
     * String with all characteristics
     * @return Formatted Clothing with size
     */
    @Override
    public String toString() {
        return (super.toString() + " Size: " + getSize());
    }
}
