/**
 * -------------------------------------------------------------------------
 * File Name: Electronic.java
 * Project: Inventory Management System
 * Description: Represents an electronic item with warranty information
 *              Extends BasicItem.
 * -------------------------------------------------------------------------
 */

package ims.model;

/**
 * An electronic item that includes a warranty period in months in addition
 * to the common item properties from {@link BasicItem}.
 */
public class Electronic extends BasicItem {
    /** Warranty duration in months (non-negative). */
    private int warrantyMonths;

    /**
     * Constructs a new {@code Electronic}.
     *
     * @param id unique identifier
     * @param name item name
     * @param quantity non-negative quantity
     * @param unitPrice non-negative unit price
     * @param restockTrigger non-negative restock threshold
     * @param warrantyMonths warranty duration in months
     */
    public Electronic(int id, String name, int quantity, double unitPrice, int restockTrigger, int warrantyMonths) {
        super(id, name, Category.ELECTRONIC, quantity, unitPrice, restockTrigger);
        this.warrantyMonths = warrantyMonths;
    };

    /**
     * Returns the warranty duration in months.
     *
     * @return warranty months
     */
    public int getWarrantyMonths(){return warrantyMonths;};

    /**
     * Updates the warranty duration in months.
     *
     * @param warrantyMonths non-negative number of months
     */
    public void setWarrantyMonths(int warrantyMonths){
        this.warrantyMonths = warrantyMonths;
    };

    /**
     * String with all characteristics
     * @return Formatted Electronic with warranty months
     */
    @Override
    public String toString() {
        return (super.toString() + " Warranty Months: " + getWarrantyMonths());
    }

}
