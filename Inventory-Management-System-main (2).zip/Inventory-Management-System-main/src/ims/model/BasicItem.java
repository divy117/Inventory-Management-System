/**
 * -------------------------------------------------------------------------
 * File Name: BasicItem.java
 * Project: Inventory Management System
 * Description: Abstract base class that implements the Item interface and provides
 *              common fields and methods shared by all item types (e.g., id, name,
 *              category, quantity, price, timestamps). Classes like Perishable and
 *              Electronic extend this base class to reuse these shared attributes.
 * -------------------------------------------------------------------------
 */

package ims.model;

/**
 * Abstract base implementation of {@link Item} that stores shared state
 * and provides common getters/setters used by concrete item types.
 *
 * <p>Subclasses must provide their own constructors to initialize fields.</p>
 */
public abstract class BasicItem implements Item {

    /** Unique identifier for the item (immutable after construction in typical usage). */
    private int id;

    /** Human-readable name of the item. */
    private String name;

    /** Category of the item. */
    private Category category;

    /** Quantity currently in stock (non-negative). */
    private int quantity;

    /** Unit price (non-negative). */
    private double unitPrice;

    /** Threshold at or below which the item needs restocking. */
    private int restockTrigger;

    /**
     * Creates a new base item with the given properties.
     *
     * @param id unique ID
     * @param name non-empty name
     * @param category non-null category
     * @param quantity non-negative quantity
     * @param unitPrice non-negative price
     * @param restockTrigger non-negative threshold
     */
    BasicItem(int id, String name, Category category, int quantity, double unitPrice, int restockTrigger) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.restockTrigger = restockTrigger;
    };

    // Implement all interface getters

    /** {@inheritDoc} */
    @Override
    public int getID() { return id; }

    /** {@inheritDoc} */
    @Override
    public String getName() { return name; }

    /** {@inheritDoc} */
    @Override
    public Category getCategory() { return category; }

    /** {@inheritDoc} */
    @Override
    public int getQuantity() { return quantity; }

    /** {@inheritDoc} */
    @Override
    public double getUnitPrice() { return unitPrice; }

    /** {@inheritDoc} */
    @Override
    public int getRestockTrigger() { return restockTrigger; }

    // Implement all interface setters

    @Override
    public void setID(int id){ this.id = id; };

    /** {@inheritDoc} */
    @Override
    public void setName(String name) { this.name = name; }

    /** {@inheritDoc} */
    @Override
    public void setCategory(Category category) { this.category = category; }

    /** {@inheritDoc} */
    @Override
    public void setQuantity(int quantity) { this.quantity = quantity; }

    /** {@inheritDoc} */
    @Override
    public void setUnitPrice(double price) { this.unitPrice = price; }

    /** {@inheritDoc} */
    @Override
    public void setRestockTrigger(int restockTrigger) { this.restockTrigger = restockTrigger; }

    @Override
    /**
     * Formats the basic item features
     * @return String of formatted item characteristics
     */
    public String toString() {
        return String.format("%-5d %-15s %-12s %-5d %-8.2f %-5d", id, name, category, quantity, unitPrice, restockTrigger);
    };
}
