/**
 * -------------------------------------------------------------------------
 * File Name: Item.java
 * Project: Inventory Management System
 * Description: Interface defining the contract for all item types
 * -------------------------------------------------------------------------
 */

package ims.model;

/**
 * Defines the common behavior that all inventory items must implement.
 * Implementations include {@link Perishable}, {@link Electronic},
 * and {@link Clothing}.
*/
public interface Item {

    /**
     * Returns the unique identifier for this item.
     *
     * @return the ID string
     */
    int getID();

    /**
     * Returns the human-readable name of this item.
     *
     * @return the item name
     */
    String getName();

    /**
     * Returns the category of this item.
     *
     * @return the {@link Category}
     */
    Category getCategory();

    /**
     * Returns the current quantity in stock.
     *
     * @return the quantity (non-negative)
     */
    int getQuantity();


    /**
     * Returns the unit price for this item.
     *
     * @return the unit price (non-negative)
     */
    double getUnitPrice();

    /**
     * Returns the threshold at or below which the item should be restocked.
     *
     * @return the restock trigger (non-negative)
     */
    int getRestockTrigger();


    /**
     * Updates ID of an item
     * @param id non-negative item id
     */
    void setID(int id);

    /**
     * Updates the name of this item.
     *
     * @param name non-empty item name
     */
    void setName(String name);

    /**
     * Updates the category of this item.
     *
     * @param category a non-null {@link Category}
     */
    void setCategory(Category category);

    /**
     * Updates the quantity of this item.
     *
     * @param quantity non-negative quantity
     */
    void setQuantity(int quantity);

    /**
     * Updates the unit price of this item.
     *
     * @param unitPrice non-negative unit price
     */
    void setUnitPrice(double unitPrice);

    /**
     * Updates the restock trigger threshold.
     *
     * @param restockTrigger non-negative restock threshold
     */
    void setRestockTrigger(int restockTrigger);
};
