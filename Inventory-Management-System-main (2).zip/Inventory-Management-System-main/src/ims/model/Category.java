/**
 * -------------------------------------------------------------------------
 * File Name: Category.java
 * Project: Inventory Management System
 * Description: Enum representing all possible inventory categories.
 *              Includes a label for display purposes.
 * -------------------------------------------------------------------------
 */

package ims.model;

/**
 * Categories available for inventory items. Each constant has a user-friendly
 * label used for UI display and CSV writing.
 */
public enum Category {
    /** Perishable goods (e.g., food, flowers). */
    PERISHABLE("PERISHABLE"),

    /** Electronic products (e.g., mice, keyboards). */
    ELECTRONIC("ELECTRONIC"),

    /** Clothing and apparel. */
    CLOTHING("CLOTHING");

    /** Human-friendly label for display purposes. */
    private final String label;

    /**
     * Creates a category with the given label.
     *
     * @param label display label for this category
     */
    Category(String label){
        this.label = label;
    };

    /**
     * Returns the user-friendly label for this category.
     *
     * @return the label string
     */
    @Override
    public String toString() {
        return label;
    };

};
