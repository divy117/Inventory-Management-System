/**
 * Contains all data model classes for the system, including the
 * abstract base Item class and its specific subclasses such as
 * Perishable, Electronic, and Clothing.
 */
package ims.model;