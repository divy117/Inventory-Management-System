/**
 * -------------------------------------------------------------------------
 * File Name: Perishable.java
 * Project: Inventory Management System
 * Description: Represents a perishable inventory item with an expiry date
 *              and storage temperature. Extends BasicItem.
 * -------------------------------------------------------------------------
 */

package ims.model;

import java.time.LocalDate;

/**
 * A perishable item with an {@link #expiryDate}
 * requirement in addition to the common fields from {@link BasicItem}.
 */
public class Perishable extends BasicItem {

    /** Expiration date; items are considered expired if before today's date. */
    private LocalDate expiryDate;

    /**
     * Constructs a new {@code Perishable}.
     *
     * @param id unique identifier
     * @param name item name
     * @param quantity non-negative quantity
     * @param unitPrice non-negative unit price
     * @param restockTrigger non-negative restock threshold
     * @param expiryDate expiration date
     */
    public Perishable(int id, String name, int quantity, double unitPrice, int restockTrigger, LocalDate expiryDate){
      super(id, name, Category.PERISHABLE, quantity, unitPrice, restockTrigger);
      this.expiryDate = expiryDate;
    };

    /**
     * Sets the expiration date.
     *
     * @param expiryDate the new expiration date
     */
    public void setExpiryDate(LocalDate expiryDate){
        this.expiryDate = expiryDate;
    };

    /**
     * Returns the expiration date of this item.
     *
     * @return the {@link LocalDate} the item expires
     */
    public LocalDate getExpiryDate(){ return this.expiryDate;};

    /**
     * String with all characteristics
     * @return Formatted Perishable with expiry date
     */
    @Override
    public String toString() {
        return (super.toString() + " Expiry Date: " + getExpiryDate());
    }
}
