/**
 * -------------------------------------------------------------------------
 * File Name: MainFrame.java
 * Project: Inventory Management System
 * Description: The primary GUI window for the Inventory Management System.
 *              Works with the backend (InventorySystem) class functionality.
 * -------------------------------------------------------------------------
 */
package ims.ui;

import ims.logic.InventorySystem;
import ims.model.*;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;


/**
 * The main application window for the Inventory Management System.
 * This class builds the GUI, attaches all toolbar actions, and connects
 * user interactions to the backend. It displays items
 * through a JTable and supports loading, saving, searching, sorting,
 * adding, deleting, and updating inventory items.
 */
public class MainFrame extends JFrame {

    /** Backend system that manages all items and file operations. */
    private final InventorySystem sys;

    /** Toolbar containing all action buttons and controls. */
    private final Toolbar tb = new Toolbar();

    private final Searchbar sb = new Searchbar();

    /** Table used to display inventory items. */
    private JTable itemTable;

    /** Table model that stores the data shown in the table. */
    private DefaultTableModel model;


    /**
     * Creates the main application window.
     *
     * @param sys the InventorySystem used for item storage and logic
     */
    public MainFrame(InventorySystem sys) {
        super("Inventory Management System");
        this.sys = sys;

        // Frame behaviour
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLayout(new BorderLayout());
        setResizable(false);
        setLocationRelativeTo(null);


        // Main function that builds our UI
        this.buildUI();
    }

    /**
     * Builds the main layout by adding the toolbar and constructing
     * the table that displays the inventory items.
     */
    private void buildUI(){
        setupToolbarFunctionality();
        setupSearchbarFunctionality();
        add(tb, BorderLayout.NORTH);
        add(sb, BorderLayout.SOUTH);
        buildTable();
    };

    private void setupSearchbarFunctionality(){
        // ---------------------- SEARCH LISTENER ----------------------
        // Uses a lambda function, but it just implements the SearchCallback
        // interface which only has one method called callback. It takes in a
        // string, but that string is passed into it when the actionListener
        // fires.
        sb.attachSearchListener((String searchedField, String searchType) -> {
            String query = searchedField.trim();
            if (query.isEmpty()){
                refresh();
                return;
            }

            ArrayList<Item> foundItems = new ArrayList<>();

            try {
                if (searchType.equals("Name")) {
                    foundItems = sys.searchByName(searchedField);
                } else if (searchType.equals("ID")) {
                    foundItems = sys.searchByID(Integer.parseInt(searchedField));
                } else if (searchType.equals("Category")) {
                    foundItems = sys.searchByCategory(searchedField);
                } else if (searchType.equals("Price")){
                    foundItems = sys.searchByPrice(Double.parseDouble(searchedField));
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(
                        this,
                        e.getMessage(),
                        "Searching Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            if (foundItems.isEmpty()) {
                JOptionPane.showMessageDialog(
                        this,
                        "No items matched your search.",
                        "Empty Search",
                        JOptionPane.INFORMATION_MESSAGE
                );
                return;
            }

            // We only set the row count to 0 if we are sure we have items to display
            model.setRowCount(0);

            for (Item found : foundItems){
                Object[] row = new Object[]{
                        found.getID(),
                        found.getName(),
                        found.getCategory(),
                        found.getQuantity(),
                        found.getUnitPrice(),
                        "Qty. <= " + found.getRestockTrigger() + " items",
                        "-",
                        "-",
                        "-"
                };

                if (found.getCategory() == Category.PERISHABLE){
                    row[6] = ((Perishable) found).getExpiryDate();
                } else if (found.getCategory() == Category.ELECTRONIC){
                    row[7] = ((Electronic) found).getWarrantyMonths();
                } else if (found.getCategory() == Category.CLOTHING){
                    row[8] = ((Clothing) found).getSize();
                }

                model.addRow(row);
            }
        });
    }

    /**
     * Connects all toolbar actions to the appropriate logic.
     * This includes: Loading and saving files, Adding new items,
     * Updating selected items, Deleting selected items, Search bar,
     * and Sorting data using the sort dropdown.
     */
    private void setupToolbarFunctionality(){

        // ---------------------- LOAD BUTTON ----------------------
        tb.attachLoadListener(() ->{
            // Defaults to the "data" folder in the project directory
            JFileChooser chooser = new JFileChooser(new File("data"));
            chooser.setDialogTitle("Select Inventory File to Manage");
            chooser.setFileFilter(new FileNameExtensionFilter(".CSV ONLY", "csv"));

            // Open the system file picker
            int status = chooser.showOpenDialog(this);

            if (status == JFileChooser.APPROVE_OPTION){
                String filePath = chooser.getSelectedFile().getAbsolutePath();

                try {
                    sys.loadFromFile(filePath);
                } catch (Exception e){
                    JOptionPane.showMessageDialog(this,
                            "File Error: " + e.getMessage(),
                            "File Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                    System.exit(0);
                }

                JOptionPane.showMessageDialog(this,
                        "File contents loaded successfully ",
                        "Loaded Items",
                        JOptionPane.INFORMATION_MESSAGE
                );

                refresh();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Error loading file please try again.",
                        "Unable to load contents of file",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        // ---------------------- SAVE BUTTON ----------------------
        tb.attachSaveListener(() ->{
            try {
                sys.saveToFile();

                JOptionPane.showMessageDialog(this,
                        "Contents saved to file.",
                        "Successful Save",
                        JOptionPane.INFORMATION_MESSAGE
                );

                refresh();

            } catch (Exception e){
                JOptionPane.showMessageDialog(this,
                        "Error: " + e.getMessage(),
                        "Unable to save contents to file",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        // ---------------------- ADD BUTTON ----------------------
        tb.attachAddListener(() ->{
            if (sys.getCurrentFilePath().isEmpty()){
                JOptionPane.showMessageDialog(this,
                        "You can not add an item without loading a file first",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            // Window pop up
            JPanel popup = new JPanel(new GridLayout(0, 2, 5, 5));

            // All the basic fields for the user to fill out
            JTextField nameForm = new JTextField();
            JTextField quantityForm = new JTextField();
            JTextField unitPriceForm = new JTextField();
            JTextField restockTriggerForm = new JTextField();
            JComboBox<Category> categoryForm = new JComboBox<>(Category.values());

            // The extra fields
            JTextField expiryForm = new JTextField();
            JTextField warrantyForm = new JTextField();
            JTextField sizeForm = new JTextField();

            // Add all of these fields to our pop up window with labels
            popup.add(new JLabel("Name:"));
            popup.add(nameForm);
            popup.add(new JLabel("Category:"));
            popup.add(categoryForm);
            popup.add(new JLabel("Quantity:"));
            popup.add(quantityForm);
            popup.add(new JLabel("Unit Price:"));
            popup.add(unitPriceForm);
            popup.add(new JLabel("Restock @:"));
            popup.add(restockTriggerForm);
            popup.add(new JLabel("Expiry Date (YYYY-MM-DD):"));
            popup.add(expiryForm);
            popup.add(new JLabel("Warranty Months:"));
            popup.add(warrantyForm);
            popup.add(new JLabel("Size:"));
            popup.add(sizeForm);

            // Here we can conditionally display which field is displayed depending on the selected
            // category

            categoryForm.addActionListener(e-> {
                Category cat = (Category) categoryForm.getSelectedItem();

                if (cat == Category.PERISHABLE) {
                    expiryForm.setVisible(true);
                    expiryForm.setText("");
                    warrantyForm.setVisible(false);
                    warrantyForm.setText("");
                    sizeForm.setVisible(false);
                    sizeForm.setText("");
                } else if (cat == Category.ELECTRONIC){
                    expiryForm.setVisible(false);
                    expiryForm.setText("");
                    warrantyForm.setVisible(true);
                    warrantyForm.setText("");
                    sizeForm.setVisible(false);
                    sizeForm.setText("");
                } else if (cat == Category.CLOTHING) {
                    expiryForm.setVisible(false);
                    expiryForm.setText("");
                    warrantyForm.setVisible(false);
                    warrantyForm.setText("");
                    sizeForm.setVisible(true);
                    sizeForm.setText("");
                } else {
                    throw new IllegalStateException("Unexpected value: " + cat);
                }
            });

            // This defaults the selected option to perishable, this way
            // the other fields cant be chosen unless the category is changed
            categoryForm.setSelectedIndex(0);

            // The form actually shows up on screen here
            int option = JOptionPane.showConfirmDialog(
                    this,
                    popup,
                    "Add New Item to System",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            // Logic for actually adding the object
            try {

                if (option == JOptionPane.OK_OPTION){

                    // Convert all of the regular fields to their respective types
                    String name = nameForm.getText();
                    Category category = (Category) categoryForm.getSelectedItem();
                    int quantity = Integer.parseInt(quantityForm.getText());
                    double unitPrice = Double.parseDouble(unitPriceForm.getText());
                    int restockTrigger = Integer.parseInt(restockTriggerForm.getText());
                    Item addedItem = null;

                    // Form Validation
                    // Can not have - values anywhere, can not have missing fields
                    if (name.isEmpty()){
                        throw new IllegalArgumentException("Please fill out all fields");
                    }

                    if (name.startsWith("-")){
                        throw new IllegalArgumentException("Name can not have negative values.");
                    }

                    if (quantity < 0 || unitPrice < 0 || restockTrigger < 0){
                        throw new IllegalArgumentException("Quantity, Unit Price, and Restock Trigger can not be <= 0");
                    }


                    // Specific item validaiton
                    if (category == Category.PERISHABLE){

                        if (expiryForm.getText().isEmpty()){
                            throw new IllegalArgumentException("You must provide a expiry date");
                        }

                        LocalDate expiry;

                        try {
                            expiry = LocalDate.parse(expiryForm.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                        } catch (DateTimeParseException e) {
                            JOptionPane.showMessageDialog(this,
                                    "Invalid date format, use YYYY-MM-DD",
                                    "Invalid Date Format",
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        };

                        addedItem = sys.addItem(new Perishable(sys.generateID(), name, quantity, unitPrice, restockTrigger, expiry));

                    } else if (category == Category.ELECTRONIC){
                        if (warrantyForm.getText().isEmpty()){
                            throw new IllegalArgumentException("You must provide a # of months");
                        }

                        int warranty = Integer.parseInt(warrantyForm.getText());

                        if (warranty < 0){
                            throw new IllegalArgumentException("Warranty months can not be less than 0");
                        }

                        addedItem = sys.addItem(new Electronic(sys.generateID(), name, quantity, unitPrice, restockTrigger, warranty));
                        
                    } else if (category == Category.CLOTHING) {

                        if (sizeForm.getText().isEmpty()){
                            throw new IllegalArgumentException("You must provide a size");
                        }

                        String size = sizeForm.getText();

                        if (size.startsWith("-")){
                            throw new IllegalArgumentException("Size can not be a negative number");
                        }

                        addedItem = sys.addItem(new Clothing(sys.generateID(), name, quantity, unitPrice, restockTrigger, size));
                    }

                    refresh();
                    JOptionPane.showMessageDialog(
                            this,
                            "Item with id " + addedItem.getID() + " has been added to the system",
                            "Item Added",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                };

            } catch (Exception e){
                JOptionPane.showMessageDialog(
                        this,
                        "Error adding item: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }

        });

        // ---------------------- DELETE BUTTON ----------------------
        tb.attachDeleteListener(() ->{
            int rowNum = itemTable.getSelectedRow();

            if (rowNum == -1){
                JOptionPane.showMessageDialog(
                        this,
                        "You must select a row before attempting to delete",
                        "Select an Item",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } else {

                Object id = itemTable.getValueAt(rowNum, 0);
                sys.removeItem(((Integer) id));

                refresh();

                JOptionPane.showMessageDialog(
                        this,
                        "Item with ID: " + ((Integer) id) + " was removed.",
                        "Successful Removal",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

        });

        // ---------------------- UPDATE BUTTON ----------------------
        tb.attachUpdateListener(() ->{
            // Gets the ID for the object we are looking for
            int rowNum = itemTable.getSelectedRow();

            if (rowNum == -1){
                JOptionPane.showMessageDialog(
                        this,
                        "Select a row before attempting to update",
                        "Select an Item",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } else {

                Item selectedItem = sys.getItem(((Integer) itemTable.getValueAt(rowNum, 0)));

                // Window pop up
                JPanel popup = new JPanel(new GridLayout(0, 2, 5, 5));

                // All the basic fields for the user to fill out
                JTextField idForm = new JTextField();
                JTextField nameForm = new JTextField();
                JTextField quantityForm = new JTextField();
                JTextField unitPriceForm = new JTextField();
                JTextField restockTriggerForm = new JTextField();
                JComboBox<Category> categoryForm = new JComboBox<>(Category.values());

                // The extra fields
                JTextField expiryForm = new JTextField();
                JTextField warrantyForm = new JTextField();
                JTextField sizeForm = new JTextField();

                // The user can see the ID but can not edit it.
                idForm.setText(Integer.toString(selectedItem.getID()));
                idForm.setEnabled(false);
                idForm.setVisible(true);

                nameForm.setText(selectedItem.getName());
                quantityForm.setText(Integer.toString(selectedItem.getQuantity()));
                unitPriceForm.setText(Double.toString(selectedItem.getUnitPrice()));
                restockTriggerForm.setText(Integer.toString(selectedItem.getRestockTrigger()));

                Category selectedCategory = selectedItem.getCategory();

                if (selectedItem instanceof Perishable) {
                    expiryForm.setText(((Perishable) selectedItem).getExpiryDate().toString());
                } else if (selectedItem instanceof Electronic) {
                    warrantyForm.setText(
                            Integer.toString(((Electronic) selectedItem).getWarrantyMonths())
                    );
                } else if (selectedItem instanceof Clothing) {
                    sizeForm.setText(((Clothing) selectedItem).getSize());
                }

                // Add all of these fields to our pop up window with labels
                popup.add(new JLabel("ID:"));
                popup.add(idForm);
                popup.add(new JLabel("Name:"));
                popup.add(nameForm);
                popup.add(new JLabel("Category:"));
                popup.add(categoryForm);
                popup.add(new JLabel("Quantity:"));
                popup.add(quantityForm);
                popup.add(new JLabel("Unit Price:"));
                popup.add(unitPriceForm);
                popup.add(new JLabel("Restock @:"));
                popup.add(restockTriggerForm);
                popup.add(new JLabel("Expiry Date (YYYY-MM-DD):"));
                popup.add(expiryForm);
                popup.add(new JLabel("Warranty Months:"));
                popup.add(warrantyForm);
                popup.add(new JLabel("Size:"));
                popup.add(sizeForm);

                categoryForm.addActionListener(e-> {
                    Category cat = (Category) categoryForm.getSelectedItem();

                    if (cat == Category.PERISHABLE) {
                        expiryForm.setVisible(true);
                        warrantyForm.setVisible(false);
                        warrantyForm.setText("");
                        sizeForm.setVisible(false);
                        sizeForm.setText("");
                    } else if (cat == Category.ELECTRONIC){
                        expiryForm.setVisible(false);
                        expiryForm.setText("");
                        warrantyForm.setVisible(true);
                        sizeForm.setVisible(false);
                        sizeForm.setText("");
                    } else if (cat == Category.CLOTHING) {
                        expiryForm.setVisible(false);
                        expiryForm.setText("");
                        warrantyForm.setVisible(false);
                        warrantyForm.setText("");
                        sizeForm.setVisible(true);
                    } else {
                        throw new IllegalStateException("Unexpected value: " + cat);
                    }
                });

                // Sets the item
                categoryForm.setSelectedItem(selectedCategory);

                int option = JOptionPane.showConfirmDialog(
                        this,
                        popup,
                        "Edit Existing Item in System",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.PLAIN_MESSAGE
                );

                try {
                    if (option == JOptionPane.OK_OPTION){
                        String name = nameForm.getText();
                        int quantity = Integer.parseInt(quantityForm.getText());
                        double unitPrice = Double.parseDouble(unitPriceForm.getText());
                        int restockTrigger = Integer.parseInt(restockTriggerForm.getText());
                        Category category = (Category) categoryForm.getSelectedItem();

                        // Form Validation
                        // Can not have - values anywhere, can not have missing fields
                        if (name.isEmpty()){
                            throw new IllegalArgumentException("Please fill out all fields");
                        }

                        if (name.startsWith("-")){
                            throw new IllegalArgumentException("Name can not have negative values.");
                        }

                        if (quantity < 0 || unitPrice < 0 || restockTrigger < 0){
                            throw new IllegalArgumentException("Quantity, Unit Price, and Restock Trigger can not be <= 0");
                        }

                        Item updated = null;
                        if (category == Category.PERISHABLE){

                            LocalDate expiry;

                            try {

                                if (expiryForm.getText().isEmpty()){
                                    throw new IllegalArgumentException("You must provide at expiry date.");
                                }

                                expiry = LocalDate.parse(expiryForm.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                            } catch (DateTimeParseException e) {
                                JOptionPane.showMessageDialog(this,
                                        "Invalid date format, use YYYY-MM-DD",
                                        "Invalid Date Format",
                                        JOptionPane.ERROR_MESSAGE);
                                return;
                            };

                            updated = new Perishable(selectedItem.getID(), name, quantity, unitPrice, restockTrigger, expiry);

                        } else if (category == Category.ELECTRONIC){

                            if (warrantyForm.getText().isEmpty()){
                                throw new IllegalArgumentException("You must provide a # of months");
                            }

                            int warranty = Integer.parseInt(warrantyForm.getText());

                            if (warranty < 0){
                                throw new IllegalArgumentException("Warranty months can not be less than 0");
                            }

                            updated = new Electronic(selectedItem.getID(), name, quantity, unitPrice, restockTrigger, warranty);

                        } else if (category == Category.CLOTHING) {
                            if (sizeForm.getText().isEmpty()){
                                throw new IllegalArgumentException("You must provide a size");
                            }

                            String size = sizeForm.getText();

                            if (size.startsWith("-")){
                                throw new IllegalArgumentException("Size can not be a negative number");
                            }

                            updated = new Clothing(selectedItem.getID(), name, quantity, unitPrice, restockTrigger, size);

                        }

                        sys.updateItem(selectedItem.getID(), updated);
                        refresh();

                        JOptionPane.showMessageDialog(
                                this,
                                "Item with id " + selectedItem.getID() + " has been updated.",
                                "Item Updated",
                                JOptionPane.INFORMATION_MESSAGE
                        );

                    }

                } catch (Exception e){
                    JOptionPane.showMessageDialog(
                            this,
                            "Error updating item: " + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }

        });

        // ---------------------- SORT COMBO BOX LISTENER ----------------------
        // Uses a lambda function, but it just implements the SortCallback
        // interface which only has one method called callback. It takes in a
        // string, but that string is passed into it when the actionListener
        // fires. So the action listener fires, passing the sorting field to
        // the object of the interface which is here, and then we use this data
        // to make our sort selection based off of the sorting field.
        tb.attachSortListener((String selectedSortingField)->{
            switch (selectedSortingField){
                case "ID":
                    sys.sortByID();
                    break;
                case "Name":
                    sys.sortByName();
                    break;
                case "Price":
                    sys.sortByPrice();
                    break;
                case "Category":
                    sys.sortByCategory();
                    break;
                case "Quantity":
                    sys.sortByQuantity();
                    break;
            }

            refresh();
        });
    };


    /**
     * Builds the JTable used to display items. Configures the model,
     * disables cell editing, enables single-row selection, and applies
     * basic styling such as grid lines and header formatting.
     * The table is placed inside a scroll pane which gets added to
     * the main GUI.
     */
    private void buildTable(){
        Object[] cols = new Object[]{"ID", "Name", "Category", "Quantity", "Price/unit", "Restock @", "Expiry", "Warranty", "Size"};
        model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Creates table with the specified model, also forces the user to only be able to
        // select an entire row at a time, not separate fields or anything.
        itemTable = new JTable(model);
        itemTable.setRowSelectionAllowed(true);
        itemTable.setColumnSelectionAllowed(false);
        itemTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        itemTable.setShowGrid(true);
        itemTable.setShowHorizontalLines(true);
        itemTable.setShowVerticalLines(false);
        itemTable.setGridColor(Color.LIGHT_GRAY);
        itemTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        itemTable.getTableHeader().setBackground(Color.PINK);

        // This wrapper will allow us to scroll through the table, we wrap the itemTable in this wrapper
        JScrollPane scrollWrapper = new JScrollPane(itemTable);

        add(scrollWrapper, BorderLayout.CENTER);
    }

    /**
     * Updates the table to match the current contents of the InventorySystem.
     * Clears all existing rows and adds updated rows for each item.
     */
    private void refresh(){
        model.setRowCount(0);
        
        for (Item item : sys.getAllItems()) {
            Object[] row = new Object[]{
                    item.getID(),
                    item.getName(),
                    item.getCategory(),
                    item.getQuantity(),
                    item.getUnitPrice(),
                    "Qty. <= " + item.getRestockTrigger() + " items",
                    "-",
                    "-",
                    "-"
            };
            if (item.getCategory() == Category.PERISHABLE){
                row[6] = ((Perishable) item).getExpiryDate();
            } else if (item.getCategory() == Category.ELECTRONIC){
                row[7] = ((Electronic) item).getWarrantyMonths();
            } else if (item.getCategory() == Category.CLOTHING){
                row[8] = ((Clothing) item).getSize();
            }

            model.addRow(row);
        }
    }


}
