/**
 * Contains all user interface components for the application,
 * including the main window and the toolbar. These classes
 * communicate with InventorySystem to perform actions and
 * update the displayed inventory data.
 */
package ims.ui;