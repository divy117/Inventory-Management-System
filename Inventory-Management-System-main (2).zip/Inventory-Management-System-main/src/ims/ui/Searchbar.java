/**
 * -------------------------------------------------------------------------
 * File Name: Searchbar.java
 * Project: Inventory Management System
 * Description: Bottom UI search bar component for the Main GUI. Contains
 *              Dropdown, Searchbar, and callback to give functionality.
 * -------------------------------------------------------------------------
 */

package ims.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

/**
 * A JToolBar component containing a combobox, and a search field allowing users to query the system
 * The component does not perform searching itself, it just passes the options and query to the Main
 * GUI which then passes to the backend.
 */
public class Searchbar extends JToolBar {

    /** Text input box where the user types their query. */
    private final JTextField searchField = new JTextField(24);

    /** Dropdown selector that determines which field to search by. */
    private final JComboBox<String> searchCombo = new JComboBox<>(new String[]{"Name", "ID", "Category", "Price"});

    /**
     * Constructs a new Searchbar UI component.
     * Initializes placeholder behavior and builds the toolbar layout.
     */
    public Searchbar(){
        addSearchPlaceholder(searchField, "Search Query");
        setFloatable(false);
        buildSearchBar();
    }

    /**
     * Builds the UI layout of the search bar.
     */
    private void buildSearchBar(){
        JPanel searchPanel = new JPanel();
        JLabel searchLabel = new JLabel("Search:");
        JLabel searchTypeLabel = new JLabel("Select Search Type");

        searchCombo.setSelectedIndex(0);

        searchPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        searchPanel.add(searchTypeLabel);
        searchPanel.add(searchCombo);

        searchPanel.add(searchLabel);
        searchPanel.add(searchField);

        add(searchPanel);
    };

    /**
     * Adds placeholder text behavior to a text field.
     * Placeholder appears when the field is unfocused and disappears when typing.
     *
     * @param field text field to modify
     * @param placeholder text that appears when the field is empty
     */
    private void addSearchPlaceholder(JTextField field, String placeholder){
        field.setText(placeholder);
        field.setForeground(Color.GRAY);

        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setText("");
                field.setForeground(Color.blue);
            }

            @Override
            public void focusLost(FocusEvent e) {
                field.setText("");
                field.setText(placeholder);
                field.setForeground(Color.GRAY);
            }
        });
    };

    /**
     * Callback used to send search text to MainFrame.
     * MainFrame sends the search text to the backend which
     * handles the searching logic.
     */
    public interface SearchCallback{

        /**
         * Called when the user presses Enter in the search field.
         *
         * @param searchedField the text entered by the user
         * @param searchType field to search by selected by user
         */
        void callbackFunction(String searchedField, String searchType);
    };

    /**
     * Attaches a listener to the search field.
     * Fires only when the user presses Enter inside the search bar.
     *
     * @param callback the function to run when a search is submitted
     */
    public void attachSearchListener(SearchCallback callback){
        searchField.addActionListener(e->
                callback.callbackFunction(searchField.getText().trim(), (String) searchCombo.getSelectedItem())
        );
    };


}
