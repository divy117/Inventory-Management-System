/**
 * -------------------------------------------------------------------------
 * File Name: Toolbar.java
 * Project: Inventory Management System
 * Description: Top UI control bar component for the Main GUI. Contains
 *              buttons and hooks to give the buttons functionality.
 * -------------------------------------------------------------------------
 */

package ims.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * The Toolbar class represents the top control bar of the application.
 * It contains buttons for loading, saving, adding, updating, and deleting items, and sorting dropdown.
 * This class provides the user interface controls and sends callbacks to MainFrame when actions occur.
 */
public class Toolbar extends JToolBar {
    /**
     * Dropdown menu containing sorting methods.
     */
    private final JComboBox<String> sortCombo = new JComboBox<>(new String[]{"ID", "Name", "Price", "Category", "Quantity"});

    /**
     * Button used to load inventory data from a CSV file.
     */
    private final JButton loadBtn = customButton("Load");

    /**
     * Button used to save inventory data back to a CSV file.
     */
    private final JButton saveBtn = customButton("Save");

    /**
     * Button used to add a new item through a popup form.
     */
    private final JButton addBtn = customButton("Add");

    /**
     * Button used to delete the currently selected item.
     */
    private final JButton deleteBtn = customButton("Delete");


    /**
     * Button used to update the currently selected item.
     */
    private final JButton updateBtn = customButton("Update");


    /**
     * Constructs the toolbar, sets styling properties, and builds all internal components.
     */
    public Toolbar(){
        setFloatable(false);
        setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        buildToolbar();
    };


    /**
     * Builds the internal layout of the toolbar including:
     * storage buttons, item management buttons, and sorting dropdown.
     * The layout is organized using FlowLayout inside panel groups.
     */
    private void buildToolbar(){
        setLayout(new FlowLayout(FlowLayout.CENTER, 45, 4));

        // Storage Panel Buttons
        JPanel storagePanel = new JPanel();
        storagePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        storagePanel.add(loadBtn);
        storagePanel.add(saveBtn);

        // Functionality Panel Buttons
        JPanel functionalityPanel = new JPanel();
        functionalityPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        functionalityPanel.add(addBtn);
        functionalityPanel.add(deleteBtn);
        functionalityPanel.add(updateBtn);

        // Search and Sorting Panel Dropdown
        JPanel searchSortPanel = new JPanel();
        JLabel sortLabel = new JLabel("Sort:");
        sortCombo.setSelectedIndex(0);
        searchSortPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        searchSortPanel.add(sortLabel);
        searchSortPanel.add(sortCombo);


        // Add panels to toolbar
        add(storagePanel);
        add(functionalityPanel);
        add(searchSortPanel);
    }

    /**
     * Creates a styled JButton to keep all toolbar buttons visually consistent.
     *
     * @param text label to display on the button
     * @return a styled JButton instance
     */
    private JButton customButton(String text) {
        JButton b = new JButton(text);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setMargin(new Insets(3, 8, 3, 8));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    };

    // -------------------------------------------------------------------------
    // CALLBACK ATTACHMENT METHODS (Used by MainFrame)
    // -------------------------------------------------------------------------

    /**
     * Attaches a callback that will run when the Load button is pressed.
     * MainFrame uses this to open a JFileChooser, select a CSV file,
     * and pass the file path into InventorySystem.loadFromFile().
     *
     * @param r code to execute on Load button click
     */
    public void attachLoadListener(Runnable r){loadBtn.addActionListener(e -> r.run());};

    /**
     * Attaches a callback for when the Save button is pressed.
     * MainFrame typically uses this to call InventorySystem.saveToFile(),
     * saving all current changes back to the CSV.
     *
     * @param r code to execute on Save button click
     */
    public void attachSaveListener(Runnable r){saveBtn.addActionListener(e -> r.run());};

    /**
     * Attaches a callback for when the Add button is pressed.
     * MainFrame uses this to open the item creation form, validate the input,
     * and insert a new item into the InventorySystem.
     *
     * @param r code to execute on Add button click
     */
    public void attachAddListener(Runnable r){addBtn.addActionListener(e->r.run());};

    /**
     * Attaches a callback for when the Delete button is pressed.
     * MainFrame uses this to check the current table selection, remove the
     * selected item from InventorySystem, and refresh the table.
     *
     * @param r code to execute on Delete button click
     */
    public void attachDeleteListener(Runnable r){deleteBtn.addActionListener(e->r.run());};

    /**
     * Attaches a callback for when the Update button is pressed.
     * MainFrame uses this to open the edit form, load existing values into it,
     * validate changes, and update the corresponding item in InventorySystem.
     *
     * @param r code to execute on Update button click
     */
    public void attachUpdateListener(Runnable r){updateBtn.addActionListener(e -> r.run());};


    // -------------------------------------------------------------------------
    // SORT CALLBACK
    // -------------------------------------------------------------------------

    /**
     * Callback used to notify MainFrame which sorting option was selected.
     * The toolbar only reports the user's choice. MainFrame calls backend
     * to perform sorting based off of the user's choice.
     */
    public interface SortCallback {
        /**
         * Called when the user changes the sorting dropdown.
         *
         * @param selectedSortingField the selected sorting category
         */
        void callbackFunction(String selectedSortingField);
    };

    /**
     * Attaches a listener to the sorting dropdown.
     * Triggers whenever the user selects a new sorting option.
     *
     * @param callback the function to run when sorting changes
     */
    public void attachSortListener(SortCallback callback){
        sortCombo.addActionListener(e->
                callback.callbackFunction((String) sortCombo.getSelectedItem()));
    };

}
