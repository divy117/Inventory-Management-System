/**
 * Root package for the Inventory Management System application.
 * Contains the main entry point and organizes all subpackages for
 * the user interface, business logic, models, and utility functions.
 */
package ims;