/**
 * Contains the core logic of the Inventory Management System.
 * This includes the InventorySystem class that manages items,
 * performs sorting, searching, and handles file operations.
 */

package ims.logic;