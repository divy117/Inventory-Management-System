/**
 * -------------------------------------------------------------------------
 * File Name: InventorySystem.java
 * Project: Inventory Management System
 * Description: This is the system that manages all of the products. It handles
 *              all CRUD operations and allows the GUI to interact with it.
 * -------------------------------------------------------------------------
 */


package ims.logic;

import ims.model.*;
import ims.util.Utilities;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


/**
 * The InventorySystem class serves as the main backend manager for all inventory data.
 * It stores every item in memory and provides methods for adding, removing, updating,
 * sorting, and searching items. It also handles storage operations.
 */
public class InventorySystem {
    /**
     * List of all items currently loaded into memory.
     * This list is the main in-memory storage for the inventory.
     */
    private List<Item> items = new ArrayList<>();

    /**
     * Full path to the currently loaded CSV file.
     * Used when saving data back to the same file.
     * May be {@code null} if no file has been loaded yet.
     */
    private String currentFilePath = "";

    /**
     * Counter used to generate unique integer IDs for items.
     * Starts at 1000 and increments each time an ID is generated.
     */
    private int nextID = 1000;

    /**
     * Generates a unique ID for new items.
     *
     * @return the next available integer ID
     */
    public int generateID(){
        return nextID++;
    };

    public void resetSystem(){
        nextID = 1000;
        items.clear();
        setCurrentFilePath("");
    }

    public void setCurrentFilePath(String path){
        this.currentFilePath = path;
    }

    public String getCurrentFilePath(){
        return currentFilePath;
    }


    // -------------------------------------------------------------------------
    // CRUD OPERATIONS
    // -------------------------------------------------------------------------

    /**
     * Adds a new item to the system.
     *
     * @param item the Item object to add
     * @return the added item
     * @throws IllegalArgumentException if the item is null or if an item with the
     *         same ID already exists
     */
    public Item addItem(Item item){
        if (item == null) {
            throw new IllegalArgumentException("Invalid item provided");
        }

        for (Item item_index : items){
            if (item_index.getID() == item.getID()){
                throw new IllegalArgumentException("An item with ID: " + item.getID() + " already exists.");
            }
        }

        items.add(item);
        return item;
    };

    /**
     * Retrieves all items currently stored in the system.
     *
     * @return a List of all Item objects
     */
    public List<Item> getAllItems(){
        return items;
    };

    /**
     * Removes an item from the system based on its ID.
     *
     * @param id the ID of the item to be removed
     */
    public void removeItem(int id){
        int removalIdx = -1;
        if (id < 0){
            throw new IllegalArgumentException("ID can not be a negative value");
        }

        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getID() == id){
                removalIdx = i;
            }
        }

        if (removalIdx == -1){
            throw new IllegalArgumentException("Item with this ID does not exist.");
        }

        items.remove(removalIdx);
    }

    /**
     * Updates an existing item by replacing it with a new version.
     *
     * @param id the ID of the item to update
     * @param updatedItem the new item to replace the old one
     */
    public void updateItem(int id, Item updatedItem){
        int updateIdx = -1;
         if (id < 0){
             throw new IllegalArgumentException("ID can not be a negative value");
         }

        for (int i = 0; i < items.size(); i++){
            if (items.get(i).getID() == id){
                updateIdx = i;
                break;
            }
        }

        if (updateIdx == -1){
            throw new IllegalArgumentException("Item with this ID does not exist.");
        }

        items.set(updateIdx, updatedItem);

    }

    /**
     * SEARCHING METHOD
     */

    /**
     * Searches for an item by its name using binary search.
     * Automatically sorts the list by name before searching.
     *
     * @param name the name of the item to search for
     * @return List containing item's with provided name, or empty list.
     */
    public ArrayList<Item> searchByName(String name){
        // First we ensure that the list is sorted by name, the user won't see this on the table
        sortByName();
        int start = 0;
        int end = items.size()-1;
        return Utilities.binarySearch(items, name, start, end);
    };

    /**
     * Searches for an item by its ID using linear search.
     *
     * @param id the id of the item to search for
     * @return List containing 1 matching Item, or empty list. ID's are unique.
     */
    public ArrayList<Item> searchByID(int id){
        ArrayList<Item> found = new ArrayList<>();

        // Invalid ID
        if (id < 1000){
            throw new IllegalArgumentException("Invalid ID Search");
        }

        for (Item item : items) {
            if (item.getID() == id) {
                found.add(item);
                break;
            }
        }

        return found;
    };


    /**
     * Searches for an item by its category using linear search.
     *
     * @param category the category of the item to search for
     * @return List containing matching Items, or empty list.
     */
    public ArrayList<Item> searchByCategory(String category){
        ArrayList<Item> found = new ArrayList<>();
        category = category.trim().toUpperCase();

        try {
            Category searched_category = Category.valueOf(category.trim().toUpperCase());

            for (Item item : items) {
                if (item.getCategory() == searched_category) {
                    found.add(item);
                }
            }
        } catch (Exception e){
            throw new IllegalArgumentException("Invalid Category Entered");
        }

        return found;
    };

    /**
     * Searches for an item by its category using linear search.
     *
     * @param price the price we are searching for
     * @return List containing items equal to or less than provided price, or empty list.
     */
    public ArrayList<Item> searchByPrice(double price){
        ArrayList<Item> found = new ArrayList<>();

        for (Item item : items) {
            if (item.getUnitPrice() <= price) {
                found.add(item);
            }
        }
        return found;
    }

    /**
     * SORTING METHODS
     */

    /**
     * Retrieves an item by its ID.
     *
     * @param id the ID of the item to find
     * @return the matching Item, or null if not found
     */
    public Item getItem(int id){
        for (Item item : items){
            if (item.getID() == id){
                return item;
            }
        }
        return null;
    }

    /**
     * Sorts all items in ascending order based on their ID.
     */
    public void sortByID() {
        for (int i = 0; i < items.size(); i++) {
            for (int j = i+1; j < items.size(); j++) {
                if (items.get(i).getID() > items.get(j).getID()) {
                    Utilities.swap(items, i, j);
                }
            }
        }

    }

    /**
     * Sorts items alphabetically by their name (case-insensitive).
     */
    public void sortByName(){
        for (int i = 0; i < items.size(); i++){
            for (int j = i+1; j < items.size(); j++){
                if(items.get(i).getName().compareToIgnoreCase(items.get(j).getName()) > 0){
                    Utilities.swap(items, i, j);
                }
            }
        }
    };

    /**
     * Sorts items by their unit price in ascending order.
     */
    public void sortByPrice(){
        for (int i = 0; i < items.size(); i++) {
            for (int j = i+1; j < items.size(); j++) {
                if (items.get(i).getUnitPrice() > items.get(j).getUnitPrice()){
                    Utilities.swap(items, i, j);
                }
            }
        }
    };

    /**
     * Sorts items by their category based on enum order (not alphabetical).
     */
    public void sortByCategory(){
        // This method compares the Enums based off of the order that they are declared.
        // It doesn't do it lexicographically
        for (int i = 0; i < items.size(); i++){
            for (int j = i+1; j < items.size(); j++){
                if (items.get(i).getCategory().compareTo(items.get(j).getCategory()) > 0){
                    Utilities.swap(items, i, j);
                }
            }
        }
    };

    /**
     * Sorts items by their quantity in ascending order.
     */
    public void sortByQuantity(){
        for (int i = 0; i < items.size(); i++) {
            for (int j = i+1; j < items.size(); j++) {
                if (items.get(i).getQuantity() > items.get(j).getQuantity()){
                    Utilities.swap(items, i, j);
                }
            }
        }
    };

    /**
     * STORAGE METHODS
     */

    /**
     * Loads inventory data from a CSV file. Existing data in memory is NOT cleared.
     *
     * CSV Format:
     *   name,category,quantity,unitPrice,restockTrigger,expiry,warranty,size
     *
     * Lines with missing content are skipped automatically.
     *
     * @param pathToCSV the file path of the CSV to load
     * @throws IllegalArgumentException if the path is missing or invalid
     */
    public void loadFromFile(String pathToCSV){
        // Checks if path is actually given
        if (pathToCSV == null || pathToCSV.isEmpty()) {
            throw new IllegalArgumentException("File does not exist");
        }

        resetSystem();
        // Create a File object since we know we have a path
        File inputFile = new File(pathToCSV);
        this.currentFilePath = pathToCSV;

        try (Scanner input = new Scanner(inputFile)){
            // This is specifically for the header of the CSV file, we check if there is a line AFTER
            // the header. If there is we just move our cursor to the next line.
            if (input.hasNextLine()){
                input.nextLine();
            }

            // While the next line exists, run this loop
            while(input.hasNextLine()){
                // We take the entire line first
                String line = input.nextLine();

                if (line.isEmpty()) continue;

                // Split the columns using commas because we are using CSV format files
                String[] cols = line.split(",");

                // Assign each column to a variable.
                String name = cols[0];

                String categoryStr = cols[1];
                int quantity = Integer.parseInt(cols[2]);
                double unitPrice = Double.parseDouble(cols[3]);
                int restockTrigger = Integer.parseInt(cols[4]);

                String expiry = cols[5];
                String warranty = cols[6];
                String size = cols[7];

                Category cat;
                try {
                    cat = Category.valueOf(categoryStr.trim().toUpperCase());
                } catch (Exception e){
                    System.err.println("Unknown category in CSV: " + categoryStr);
                    continue;
                }

                if (cat == Category.PERISHABLE){
                    this.addItem(new Perishable(generateID(), name, quantity, unitPrice, restockTrigger, LocalDate.parse(expiry)));
                } else if (cat == Category.ELECTRONIC){
                    this.addItem(new Electronic(generateID(), name, quantity, unitPrice, restockTrigger, Integer.parseInt(warranty)));
                } else if (cat == Category.CLOTHING) {
                    this.addItem(new Clothing(generateID(), name, quantity, unitPrice, restockTrigger, size));
                };

            };
        } catch (Exception e) {
            // Just throws the exception that we get if things go wrong while reading file
            throw new RuntimeException("Error writing to the file: " + e.getMessage(), e);
        }

    };


    /**
     * Saves the current inventory data to the CSV file that was originally loaded.
     * Overwrites the existing file with updated content.
     *
     * @throws IllegalArgumentException if no file has been loaded yet
     */
    public void saveToFile(){
        if (currentFilePath == null || currentFilePath.isEmpty()){
            throw new IllegalArgumentException("You must open a file before saving to a file");
        }

        try {
            PrintWriter writer = new PrintWriter(new FileWriter(currentFilePath));
            String csvHeader = "name,category,quantity,unitPrice,restockTrigger,expiry,warranty,size";

            writer.println(csvHeader);

            for (Item item : items){
                String itemLine = item.getName() + ','
                        + item.getCategory() + ','
                        + item.getQuantity() + ','
                        + item.getUnitPrice() + ','
                        + item.getRestockTrigger() + ',';

                if (item instanceof Perishable){
                    itemLine = itemLine + ((Perishable) item).getExpiryDate() + ",-" + ",-";
                } else if (item instanceof Electronic){
                    itemLine = itemLine + "-," + ((Electronic) item).getWarrantyMonths() + ",-";
                } else if (item instanceof Clothing){
                    itemLine = itemLine + "-," + "-," + ((Clothing) item).getSize();
                }

                writer.println(itemLine);
            }

            writer.close();
            resetSystem();

        } catch (IOException e) {
            throw new RuntimeException("Error writing to the file: " + e.getMessage(), e);
        }
    }


}
