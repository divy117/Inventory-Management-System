/**
 * -------------------------------------------------------------------------
 * File Name: App.java
 * Project: Inventory Management System
 *
 * Description: Entry point of the application. Initializes the InventorySystem
 *              backend and launches the MainFrame GUI.
 * -------------------------------------------------------------------------
 */


package ims;

import ims.logic.InventorySystem;
import ims.ui.MainFrame;

import javax.swing.*;

/**
 * Entry point of the Inventory Management System application.
 * This class creates the InventorySystem backend and launches the GUI
 * on the Swing event dispatch thread.
 */
public class App {
    /**
     * Starts the program by initializing the backend system and opening
     * the main application window.
     *
     * @param args command-line arguments, not required here
     */
    public static void main(String[] args) {
        // Step 1: Create an instance of the system
        InventorySystem sys = new InventorySystem();

        // Step 2: Build GUI
        MainFrame f = new MainFrame(sys);
        f.setVisible(true);
    }
}
