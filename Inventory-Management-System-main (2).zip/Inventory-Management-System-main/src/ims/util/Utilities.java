/**
 * -------------------------------------------------------------------------
 * File Name: Utilities.java
 * Project: Inventory Management System
 *
 * Description: General purpose helper class which provides common utility
 *              functions to assist with certain methods in the system.
 * -------------------------------------------------------------------------
 */
package ims.util;

import ims.model.Item;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class containing helper methods used throughout the
 * Inventory Management System. Provides common operations such as
 * swapping items in a list and performing a binary search on a
 * sorted list of items.
 */
public class Utilities {

    /**
     * Swaps two items in a list based on their indexes.
     * This method is used by sorting algorithms in InventorySystem.
     *
     * @param items the list of items to modify
     * @param i the index of the first item
     * @param j the index of the second item
     */
    public static void swap(List<Item> items, int i, int j){
        Item temp = items.get(j);
        items.set(j, items.get(i));
        items.set(i, temp);
    }

    /**
     * Performs a recursive binary search for an item name.
     * This method assumes the list is already sorted alphabetically
     * by item name.
     *
     * @param items the sorted list of items to search
     * @param target the item name to search for
     * @param start the starting index of the search range
     * @param end the ending index of the search range
     * @return the Item with a matching name, or null if no match is found
     */
    public static ArrayList<Item> binarySearch(List<Item> items, String target, int start, int end){
        ArrayList<Item> found = new ArrayList<>();

        target = target.toLowerCase();

        if (start > end){
            return found;
        }

        while (start <= end){
            int middle = (start+end) / 2;
            String name = items.get(middle).getName().toLowerCase();
            int comparison_result = name.compareTo(target);

            if (comparison_result == 0){
                // Since some items may have the same name, we will have to add all the items to the list, so we
                // need to go before and past the middle to find all elements that have the same name.

                int i = middle;

                // We expand to the left, go down to the left
                while (i>=0 && items.get(i).getName().toLowerCase().equals(target)){
                    found.add(items.get(i));
                    i--;
                };

                i = middle+1;
                while (i < items.size() && items.get(i).getName().toLowerCase().equals(target)){
                    found.add(items.get(i));
                    i++;
                }
                return found;
            } else if (comparison_result > 0){
                // The current string we are looking at is HIGHER order than the one we need, so we need to look to the
                // left of the list.
                end = middle - 1;

            } else {
                // The current string we are looking at is LOWER order than the one we need, so we need to look to the
                // right of the list
                start = middle + 1;
            }
        }

        return found;
    };
}
