/**
 * Contains helper classes and utility methods used throughout
 * the application, including operations such as swapping items
 * and performing binary search on item lists.
 */
package ims.util;